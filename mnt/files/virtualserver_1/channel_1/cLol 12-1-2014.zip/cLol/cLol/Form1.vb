﻿Imports cMem
Imports System.Runtime.InteropServices
Imports System.Reflection
Imports System.Text
Public Class Form1
    'Private ObjManager As Integer = &H1D2E7B4 '1D29764
    'Private ObjManagerMax As Integer = &H1D2E7B8 '1D29768
    'Private LocalPlayer As Integer = &H29958C0 '2990848
    'Private HudManager As Integer = &H2996684 '29915FC '104 (camera x), 10c (camera y), 1bc (camera z)

    'Private WriteCursorY As Integer = &H3E2E05 '5 bytes f3 0f 11 46 20
    'Private WriteCursorZ As Integer = &H3E2E0D '5 bytes f3 0f 11 4e 1c
    'Private WriteCursorX As Integer = &H3E2E1A '5 bytes f3 0f 11 56 18
    Public l As LolHelpers


    Private objMgrBase As Long
    Public Shared lolBase As Long
    Private WithEvents hk As New cMem.HotKeys
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try
            hk.AddKey(Keys.LShiftKey)
            hk.AddKey(Keys.LControlKey)
            hk.AddKey(Keys.F10)
            hk.AddKey(Keys.F8)
            hk.AddKey(Keys.F7)
            hk.AddKey(Keys.F6)
            hk.AddKey(Keys.T)
            hk.AddKey(Keys.Q)
            hk.AddKey(Keys.W)
            hk.AddKey(Keys.E)
            hk.AddKey(Keys.R)

            LastHitTmr = New System.Timers.Timer(100)
            AddHandler LastHitTmr.Elapsed, AddressOf LastHitTmr_Tick
            LastHitTmr.Enabled = False
            Aimbot = New System.Timers.Timer(50)
            AddHandler Aimbot.Elapsed, AddressOf aimbot_tick
            Aimbot.Enabled = False
            PredictionTmr = New System.Timers.Timer(50)
            AddHandler PredictionTmr.Elapsed, AddressOf prediction_tick
            PredictionTmr.Enabled = False
            AutoSmiteTmr = New System.Timers.Timer(50)
            AddHandler AutoSmiteTmr.Elapsed, AddressOf AutoSmite_tick
            AutoSmiteTmr.Enabled = False
        Catch ex As Exception
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.Message)
        End Try
    End Sub
    Private Aimbot As System.Timers.Timer
    Private LastHitTmr As System.Timers.Timer
    Private PredictionTmr As System.Timers.Timer
    Private AutoSmiteTmr As System.Timers.Timer
    Private modifier_shift As Boolean = False
    Private last_object As LolClasses.LolObject
    Private current_object As LolClasses.LolObject
    Private prediction As New cMem.Memory.Vector3
    Private quick_cast As Boolean = False
    Private Sub handlekeydown(ByVal key As System.Windows.Forms.Keys) Handles hk.KeyDown
        If MS.memory.Process_Obj Is Nothing Then
            LastHitTmr.Enabled = False
            Aimbot.Enabled = False
            Exit Sub
        End If
        If last_obj Is Nothing Then last_obj = LolHelpers.getLocalPlayer

        Select Case key
            Case Keys.LShiftKey
                modifier_shift = True
                l.getInvisObjects()
                Dim s As LolClasses.LolObject = l.getObjectByName("ward")
                If s IsNot Nothing Then
                    Console.WriteLine(Hex(s.BaseAddress) & " " & s.Name)
                End If
            Case Keys.F6
                'Dim b As LolClasses.LolObject = l.GetNearestEnemy(False, False, 100000)
                LastHitTmr.Enabled = Not LastHitTmr.Enabled
                If LastHitTmr.Enabled Then
                    l.FloatingText("Last Hit Enabled", LolHelpers.FloatingTextTypes.red_fade_up)
                    ' l.PrintToChat("<font color=""#990000"">Last Hit</font> <font color=""#00ff00"">Enabled</font>")
                Else
                    l.FloatingText("Last Hit Disabled", LolHelpers.FloatingTextTypes.red_fade_up)
                    'l.PrintToChat("<font color=""#990000"">Last Hit</font> <font color=""#00ff00"">Disabled</font>")
                End If
            Case Keys.F7
                If l.findSpell("smite") = -1 Then
                    l.FloatingText("You don't have smite dumbass...", LolHelpers.FloatingTextTypes.red_bounce_fire_icon)
                    ' l.PrintToChat("<font color=""#990000"">Auto Smite</font> <font color=""#ff0000"">You don't have smite dumbass...</font>")
                Else
                    AutoSmiteTmr.Enabled = Not AutoSmiteTmr.Enabled
                    If AutoSmiteTmr.Enabled Then
                        l.FloatingText("Auto Smite Enabled", LolHelpers.FloatingTextTypes.big_white_snap)
                        ' l.PrintToChat("<font color=""#990000"">Auto Smite</font> <font color=""#ff0000"">Enabled</font>")
                    Else
                        l.FloatingText("Auto Smite Disabled", LolHelpers.FloatingTextTypes.big_white_snap)
                        ' l.PrintToChat("<font color=""#990000"">Auto Smite</font> <font color=""#ff0000"">Disabled</font>")
                    End If
                End If
            Case Keys.F8
                quick_cast = Not quick_cast
                If quick_cast Then
                    l.FloatingText("Quick Cast Enabled", LolHelpers.FloatingTextTypes.green_bounce)
                    '     l.PrintToChat("<font color=""#990000"">Quick Cast</font> <font color=""#ff0000"">Enabled</font>")
                Else
                    l.FloatingText("Quick Cast Disabled", LolHelpers.FloatingTextTypes.green_bounce)
                    ' l.PrintToChat("<font color=""#990000"">Quick Cast</font> <font color=""#ff0000"">Disabled</font>")
                End If
            Case Keys.F10

                Aimbot.Enabled = Not Aimbot.Enabled
                If Aimbot.Enabled Then
                    current_object = Nothing
                    PredictionTmr.Enabled = True
                    l.FloatingText("Aimbot Enabled", LolHelpers.FloatingTextTypes.purple_bounce)
                    '  l.PrintToChat("<font color=""#990000"">Aimbot</font> <font color=""#ff0000"">Enabled</font>")
                    LolHelpers.CursorPause = True
                Else
                    PredictionTmr.Enabled = False
                    l.FloatingText("Aimbot Disabled", LolHelpers.FloatingTextTypes.purple_bounce)
                    'l.PrintToChat("<font color=""#990000"">Aimbot</font> <font color=""#ff00ff"">Disabled</font>")
                    LolHelpers.CursorPause = False
                End If
            Case Keys.Q
                DoQuickCast(0)
            Case Keys.W
                DoQuickCast(1)
            Case Keys.E
                DoQuickCast(2)
            Case Keys.R
                DoQuickCast(3)
            Case Keys.T
                DoQuickCast(0)
                DoQuickCast(1)
                DoQuickCast(2)
                DoQuickCast(3)
        End Select

    End Sub
    Private Sub DoQuickCast(ByVal slot As Integer)
        If quick_cast Then
            Dim spell As LolClasses.LolSpell = LolHelpers.getLocalPlayer.GetSpell(slot)
            Dim b As LolClasses.LolObject = l.GetNearestEnemyChampion(spell.Range + 100)
            If b IsNot Nothing Then
                If spell.isReady Then
                    If spell.CastType = 6 Or spell.CastType = 7 Or spell.CastType = 2 Or spell.CastType = 3 Then
                        l.CastSpell(b.Location, slot)
                    ElseIf spell.CastType <> 0 Then
                        l.CastSpell(b, slot)
                    End If
                    Select Case slot
                        Case 0
                            l.FloatingText("Quick Q Target", LolHelpers.FloatingTextTypes.big_white_snap, b)
                        Case 1
                            l.FloatingText("Quick W Target", LolHelpers.FloatingTextTypes.big_white_snap, b)
                        Case 2
                            l.FloatingText("Quick E Target", LolHelpers.FloatingTextTypes.big_white_snap, b)
                        Case 3
                            l.FloatingText("Quick R Target", LolHelpers.FloatingTextTypes.big_white_snap, b)
                    End Select

                End If
                b = Nothing
            End If
        End If
    End Sub
    Private Sub handlekeyup(ByVal key As System.Windows.Forms.Keys) Handles hk.KeyUp
        If MS.memory.Process_Obj Is Nothing Then
            LastHitTmr.Enabled = False
            Aimbot.Enabled = False
            AutoSmiteTmr.Enabled = False
            quick_cast = False
            Exit Sub
        End If
        Select Case key
            Case Keys.Tab
            Case Keys.LShiftKey
                modifier_shift = False
            Case Keys.LControlKey

                'l.PrintToChat("<font color=""#990000"">Last Hit</font>: <font color=""#ff0000"">Disabled</font>")
                'LastHitTmr.Enabled = False
        End Select
    End Sub
    Dim last_smite_obj As Integer = 0
    Private Sub AutoSmite_tick(sender As Object, e As EventArgs)
        Dim b As LolClasses.LolObject = l.getNearestEpic()
        If b IsNot Nothing Then
            Dim lp As LolClasses.LolObject = LolHelpers.getLocalPlayer
            Dim smite As Integer = l.findSpell("smite")
            If smite <> -1 Then
                If LolHelpers.GetDistance(LolHelpers.getLocalPlayer.Location, b.Location) <= lp.GetSpell(smite).Range Then
                    If lp.GetSpell(smite).isReady Then
                        If b.HealthCurrent <= lp.GetSpell(smite).TrueDamage Then
                            If last_smite_obj <> b.BaseAddress Then
                                l.CastSpell(b, smite)
                                ' l.PrintToChat("<font color=""#990000"">Auto Smite</font>: </font><font color=""#009900""> " & b.Name & " " & b.CampID & "</font>")
                                l.FloatingText("What the fuck just happened?", LolHelpers.FloatingTextTypes.bottom_static_fade_out_long, b)
                            End If
                            last_smite_obj = b.BaseAddress
                        End If
                    End If
                End If
            Else
                Console.WriteLine("Smite not found")
            End If
        End If
    End Sub
    Private Sub prediction_tick(sender As Object, e As EventArgs)
        Try
            If current_object IsNot Nothing Then

                Dim current_vec As New cMem.Memory.Vector3
                Dim previous_vec As New cMem.Memory.Vector3
                Dim distance_vec As New cMem.Memory.Vector3
                current_vec = current_object.Location
                previous_vec = current_object.previous_location
                distance_vec.x = (current_vec.x - previous_vec.x)
                distance_vec.y = (current_vec.y - previous_vec.y)
                distance_vec.z = (current_vec.z - previous_vec.z)
                If current_object.Location.x = previous_vec.x AndAlso current_object.Location.y = previous_vec.y Then
                    prediction = current_object.Location
                Else
                    Dim hyp As Single = Math.Sqrt((distance_vec.x * distance_vec.x) + (distance_vec.y * distance_vec.y))
                    prediction.x = current_object.Location.x + ((current_object.MovementSpeed * (distance_vec.x / hyp)) * 0.8)
                    prediction.y = current_object.Location.y + ((current_object.MovementSpeed * (distance_vec.y / hyp)) * 0.8)
                    prediction.z = current_object.Location.z
                End If
                current_object.SaveLocation()
            End If
        Catch ex As Exception
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
        End Try
    End Sub
    Private Sub aimbot_tick(sender As Object, e As EventArgs)
        Try
            Dim lp As LolClasses.LolObject = LolHelpers.getLocalPlayer
            If lp.SpellSlot <> -1 Then
                Dim spell As LolClasses.LolSpell = lp.GetSpell(lp.SpellSlot)
                If spell.CastType = 6 Or spell.CastType = 7 Or spell.CastType = 3 Then
                    Dim b As LolClasses.LolObject = l.GetNearestEnemyChampion(spell.Range + 200)
                    If b IsNot Nothing Then
                        If current_object Is Nothing OrElse b.BaseAddress <> current_object.BaseAddress Then
                            current_object = b
                            l.FloatingText("Target", LolHelpers.FloatingTextTypes.big_white_snap, b)
                        End If
                        PredictionTmr.Enabled = True
                        LolHelpers.CursorPause = True
                        MS.memory.WriteMemory(LolHelpers.CursorVecAddress, prediction)
                    Else
                        LolHelpers.CursorPause = False
                    End If
                Else
                    LolHelpers.CursorPause = False
                End If
            End If
        Catch ex As Exception
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
        End Try
    End Sub
    Private last_obj As LolClasses.LolObject
    Private Sub LastHitTmr_Tick(sender As Object, e As EventArgs)
        Dim b As LolClasses.LolObject = l.GetNearestEnemy(False, True, 1000)
        If last_obj Is Nothing Then
            last_obj = LolHelpers.getLocalPlayer
        End If
        If b IsNot Nothing AndAlso b.BaseAddress <> last_obj.BaseAddress Then
            l.MoveTo(LolStructs.MoveType.Hold, 0, Nothing)
            last_obj = b
            l.MoveTo(LolStructs.MoveType.Attack, b.BaseAddress, Nothing)
            l.FloatingText("Last Hit Me!!", LolHelpers.FloatingTextTypes.red_bounce, b)
            'l.PrintToChat("<font color=""#990000"">Last Hit</font>:</font><font color=""#009900""> " & b.Name & "</font>")
        ElseIf b IsNot Nothing AndAlso b.BaseAddress = last_obj.BaseAddress Then
            'l.MoveTo(LolStructs.MoveType.Attack, b.BaseAddress, Nothing)
        Else
            If LolHelpers.getCursor.MoveToX = LolHelpers.getLocalPlayer.Location.x Then
                l.MoveTo(LolStructs.MoveType.Hold, 0, Nothing)
            End If
        End If
    End Sub
    Private Function getDots(ByVal count As Integer) As String
        Dim rval As New StringBuilder
        For i = 1 To count
            rval.Append(".")
        Next
        Return rval.ToString
    End Function
    Private currentDots As Integer = 0
    Private isLoading As Boolean = False
    Private Sub WaitForGame_Tick(sender As Object, e As EventArgs) Handles WaitForGame.Tick
        If MS.memory.Process_Obj IsNot Nothing Then
            If MS.memory.Process_Obj.HasExited Then
                l = Nothing
                LolHelpers.CursorThreadActive = False
                MS.memory.Process_Obj = Nothing
                LastHitTmr.Enabled = False
                Aimbot.Enabled = False
                AutoSmiteTmr.Enabled = False
                quick_cast = False
                'isLoading = False
                Console.WriteLine("Game Closed")
                Message.Text = "Game Closed"
                Exit Sub
            End If
        End If
        If MS.memory.Process_Obj Is Nothing Then
                Message.Text = "Waiting for game to start" & getDots(currentDots)
                If currentDots < 5 Then
                    currentDots += 1
                Else
                    currentDots = 0
                End If

                Dim process_list As New cMem.ProcessList("League Of Legends")
                process_list = New cMem.ProcessList("League Of Legends")
                If process_list.Processes.Values.Count = 0 Then Exit Sub
                For Each item As Process In process_list.Processes.Values
                    MS.memory.Attach(item)
                Next
        Else
            LolHelpers.lolbase = MS.memory.getModuleAddress("League Of Legends.exe")
            If LolHelpers.getCursor.CursorX = 0 Then
                Message.Text = "Game Found: Waiting to finish loading"
            Else
                If l Is Nothing Then
                    LolHelpers.CursorThreadActive = True
                    l = New LolHelpers()
                    Message.Text = "Game Found: " & LolHelpers.getLocalPlayer.Name & " (" & LolHelpers.getLocalPlayer.Champion & ")"
                End If
            End If
        End If
    End Sub

End Class
