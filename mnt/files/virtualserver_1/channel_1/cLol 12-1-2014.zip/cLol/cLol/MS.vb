﻿Public Class MS
    Public Shared memory As New cMem.Memory
End Class
