﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Message = New System.Windows.Forms.Label()
        Me.WaitForGame = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'Message
        '
        Me.Message.AutoSize = True
        Me.Message.Location = New System.Drawing.Point(12, 9)
        Me.Message.Name = "Message"
        Me.Message.Size = New System.Drawing.Size(122, 13)
        Me.Message.TabIndex = 3
        Me.Message.Text = "Waiting for game to start"
        '
        'WaitForGame
        '
        Me.WaitForGame.Enabled = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(205, 32)
        Me.Controls.Add(Me.Message)
        Me.Name = "Form1"
        Me.Text = "Clints cLol"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Message As System.Windows.Forms.Label
    Friend WithEvents WaitForGame As System.Windows.Forms.Timer

End Class
