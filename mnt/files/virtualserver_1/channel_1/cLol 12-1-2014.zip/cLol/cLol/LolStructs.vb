﻿Imports System.Runtime.InteropServices
Public Class LolStructs
    Public Enum objectType As Byte
        NotTargetable = 0
        Champ = 20
        Minion = 12
        Turret_2 = 36
    End Enum

    Public Enum SpellAddresses As Integer
        SpellInformation
        Name = &H18
    End Enum
    <StructLayout(LayoutKind.Explicit)>
       Public Structure HudManager
        <FieldOffset(&H0)> _
        Public Camera As Integer
        <FieldOffset(&H8)> _
        Public Cursor As Integer
    End Structure
    <StructLayout(LayoutKind.Explicit)>
        Public Structure CursorMoveTo
        <FieldOffset(&HC)> _
        Public CursorOnTargetX As Single

        <FieldOffset(&H10)> _
        Public CursorOnTargetZ As Single

        <FieldOffset(&H14)> _
        Public CursorOnTargetY As Single

        <FieldOffset(&H18)> _
        Public CursorX As Single

        <FieldOffset(&H1C)> _
        Public CursorZ As Single

        <FieldOffset(&H20)> _
        Public CursorY As Single

        <FieldOffset(&H24)> _
        Public MoveToX As Single

        <FieldOffset(&H28)> _
        Public MoveToZ As Single

        <FieldOffset(&H2C)> _
        Public MoveToY As Single

        <FieldOffset(&H34)> _
        Public ID1 As Integer

        <FieldOffset(&H38)> _
        Public ID2 As Integer
    End Structure

    <StructLayout(LayoutKind.Explicit)> _
    Public Structure Camera
        <FieldOffset(&H104)> _
        Public X As Single
        <FieldOffset(&H10C)> _
        Public Y As Single
        <FieldOffset(&H1BC)> _
        Public Z As Single
    End Structure
    <StructLayout(LayoutKind.Explicit)>
    Public Structure lolObject
        <FieldOffset(&H8)> _
        Public ID As Int32

        <FieldOffset(&H18)> _
        Public Team As Int32

        <FieldOffset(&H1D)> _
        Public Type As Byte

        <FieldOffset(&H24)> _
        <MarshalAs(UnmanagedType.ByValTStr, SizeConst:=15)> _
        Public Name As String

        <FieldOffset(&H34)> _
        Public Name_Length As Int32

        <FieldOffset(&H38)> _
        Public Unk1 As Int32

        <FieldOffset(&H60)> _
        Public X As Single

        <FieldOffset(&H64)> _
        Public Z As Single

        <FieldOffset(&H68)> _
        Public Y As Single

        <FieldOffset(&HFC)> _
        Public UnitID As Int32

        <FieldOffset(&H140)> _
        Public Current_Health As Single

        <FieldOffset(&H150)> _
        Public Max_Health As Single

        <FieldOffset(&H1AC)> _
        Public Current_Mana As Single

        <FieldOffset(&H1BC)> _
        Public Max_Mana As Single

        <FieldOffset(&H304)> _
        <MarshalAs(UnmanagedType.ByValTStr, SizeConst:=15)> _
        Public ArmorMaterial As String

        <FieldOffset(&H31C)> _
        <MarshalAs(UnmanagedType.ByValTStr, SizeConst:=15)> _
        Public WeaponMaterial As String

        <FieldOffset(&H4A4)> _
        Public X3 As Single

        <FieldOffset(&H4A8)> _
        Public Z3 As Single

        <FieldOffset(&H4AC)> _
        Public Y3 As Single

        <FieldOffset(&H530)> _
        <MarshalAs(UnmanagedType.ByValTStr, SizeConst:=15)> _
        Public Champion As String

        <FieldOffset(&H5E9)> _
        Public Visibility As Byte

        <FieldOffset(&H206C)> _
        Public ChampionNamePtr As Integer

        <FieldOffset(&H5B4)> _
        Public IsPlayer As Byte

        <FieldOffset(&H5D8)> _
        Public unknown As Int32

        <FieldOffset(&H680)> _
        Public Cooldown_Reduction As Single

        <FieldOffset(&H6CC)> _
        Public Bonus_Attack_Damage As Single

        <FieldOffset(&H6D4)> _
        Public Ability_Power As Single

        <FieldOffset(&H734)> _
        Public Attack_Damage As Single

        <FieldOffset(&H750)> _
        Public Armor As Single

        <FieldOffset(&H754)> _
        Public Magic_Resist As Single

        <FieldOffset(&H76C)> _
        Public Movement_Speed As Single

        <FieldOffset(&H770)> _
        Public Range As Single

        <FieldOffset(&H1184)> _
        Public Champion_SCI As Integer

        <FieldOffset(&H11AC)> _
        Public Champion_Spell_Active_Slot As Int32

        <FieldOffset(&H1678)> _
        Public SpellInstance0 As Integer

        <FieldOffset(&H2098)> _
        Public DeathDuration As Single

        <FieldOffset(&H2134)> _
        Public SkinID As Int32

        <FieldOffset(&H2298)> _
        Public CampID As Int32

        <FieldOffset(&H231C)> _
        Public Summoner_SCI As Integer

        <FieldOffset(&H2344)> _
        Public Summoner_Spell_Active_Slot As Int32

    End Structure

    Public Enum SpellLayout
        FirstSpell = &H4F4
        CurrentActiveSlot = &H28
    End Enum
    <StructLayout(LayoutKind.Explicit)>
    Public Structure GameClock
        <FieldOffset(&H2C)> _
        Public Time As Single
    End Structure

    <StructLayout(LayoutKind.Explicit)>
    Public Structure Spell
        <FieldOffset(&H14)> _
        Public CooldownTimeStamp As Single
        <FieldOffset(&H2C)> _
        Public CooldownTime As Single
        <FieldOffset(&H28)> _
        Public ToggleState As Single
        <FieldOffset(&H10)> _
        Public Level As Int32
        <FieldOffset(&HD4)> _
        Public SpellInformation As Int32
        <FieldOffset(&H44)> _
        Public TrueDamage As Single
    End Structure
    <StructLayout(LayoutKind.Explicit)>
    Public Structure SpellInformation
        <FieldOffset(&H18)> _
        <MarshalAs(UnmanagedType.ByValTStr, SizeConst:=20)> _
        Public Name As String
        <FieldOffset(&H28)> _
        Public NameLength As Integer
        <FieldOffset(&HBC)> _
        Public BaseDamage As Single '(4*level+basedamage)
        <FieldOffset(&H396)> _
        Public Unk1 As Short
        <FieldOffset(&H7AC)> _
        Public TargetType As Integer
        <FieldOffset(&H7B0)> _
        Public CastType As Integer
        <FieldOffset(&H794)> _
        Public BaseMana As Single '(4*level+BaseMana)
        <FieldOffset(&H2C0)> _
        Public BaseCoolDown As Single '(4*level+BaseMana)
        <FieldOffset(&H540)> _
        Public Range As Single '(4*level+Range)
        <FieldOffset(&H524)> _
        Public RangeRadius As Single '(4*level+Range)
        <FieldOffset(&H55C)> _
        Public RangeAoeRadius As Single '(4*level+Range)
    End Structure
    Public Enum TargettingType As Integer
        aoe = 0
        missile = 1
        self = 2
        team = 3
    End Enum
    Public Enum MoveType As Integer
        Move = 2
        Attack = 3
        Hold = &HA
        [Stop] = &HA
    End Enum


End Class
