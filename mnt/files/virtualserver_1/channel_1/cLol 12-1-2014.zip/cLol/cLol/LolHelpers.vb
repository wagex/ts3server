﻿Imports cMem
Imports System.Runtime.InteropServices
Imports System.Reflection
Imports Binarysharp.Assemblers.Fasm
Imports System.Threading
Public Class LolHelpers
    Public Enum Statics
        GameState = &H10C5820
    End Enum
    Public Enum FloatingTextTypes
        white_fade_out = 0
        yellow_fade_up = 1
        green_bounce = 2
        white_slide = 5
        red_bounce_fire_icon = 6
        purple_bounce_icon = 7
        white_bounce_icon = 8
        gold = 10
        level_up = 11
        big_white_snap = 12
        blue_fade_out = 13
        green_fade_up = 14
        white_fade_up = 15
        red_bounce = 16
        purple_bounce = 17
        white_bounce = 18
        small_red_bounce = 19
        small_purple_bounce = 20
        small_white_bounce = 21
        red_fade_up = 25
        bottom_static_fade_out_long = 26
        white_fade_up2 = 27
    End Enum
    Public Enum Structs
        ObjManager = &H1D10A34 '1D2E7B4 '1D29764
        ObjManagerMax = &H1D10A38 '1D29768
        LocalPlayer = &H2977F48 '29958F8 '2990848
        HudManager = &H2978D24 '29966B8 '29915FC 
        GameClock = &H29791A8 '2996B24
    End Enum

    Public Enum Functions
        MoveTo = &H220190 '--221AF0 '221B60
        Cast = &H36E660 '--371820 '3718E0
        PrintChat = &H3A7890 '---3A9F10 
        SetCastCursorLocation = &H348230 '--34A380 '34A420
        FloatingText = &H3BB760 '2AA390 '3BDC60
    End Enum
    Private FloatingTextUnk2 As Integer = &H29A5374
    Private FloatingTextUnk1 As Integer = &H2978564
    Private ChatMsgUnk1 As Integer = &H2962D10
    Public Shared lolbase As Integer = 0
    Public Shared MoveMouseThread As Thread
    Public Shared CursorPause As Boolean = False
    Public Shared CursorVecAddress As Integer = 0
    Public Shared CursorThreadActive As Boolean = True

    Sub New()
        lolbase = MS.memory.getModuleAddress("League Of Legends.exe")
        Console.WriteLine("Clock: " & Hex(lolbase + Structs.GameClock))
        Console.WriteLine("Hud Manager: " & Hex(lolbase + Structs.HudManager))
        Console.WriteLine("Local Player Object: " & Hex(MS.memory.readInt(lolbase + Structs.LocalPlayer)))
        Console.WriteLine("Cast: " & Hex(lolbase + Functions.Cast))
        Console.WriteLine("PrintChat: " & Hex(lolbase + Functions.PrintChat))
        Console.WriteLine("Cursor Loc: " & Hex(lolbase + Functions.SetCastCursorLocation))
        Console.WriteLine("Floating Text: " & Hex(lolbase + Functions.FloatingText))
        Console.WriteLine("Base: " & Hex(lolbase))
        Console.WriteLine("Unk1?: " & Hex(lolbase + &H367170))
        Console.WriteLine("Object Manager: " & Hex(lolbase + Structs.ObjManager))
        HookSkillMouse()
        Console.WriteLine("Floating text1: " & Hex(MS.memory.readInt(lolbase + FloatingTextUnk1)))
        Console.WriteLine("Floating text2: " & Hex(MS.memory.readInt(lolbase + FloatingTextUnk2)))
        'For i = 0 To 27
        '    FloatingText("Type: " & i, i)
        '    System.Threading.Thread.Sleep(1000)
        'Next
        'FloatingText("Current Target: " & vbCrLf & "  test", FloatingTextTypes.red_fade_up)
        FloatingText("cLol initialized", FloatingTextTypes.big_white_snap)
        FloatingText("Bitches get ready!", FloatingTextTypes.bottom_static_fade_out_long)

        PrintToChat("<font color=""#ff0000"">-------<font color=""#00ff00"">cLol Initialized</font>-------</font>")
        PrintToChat("<font color=""#00ff00"">F6 (Last Hit)</font>")
        PrintToChat("<font color=""#00ff00"">F7 (Auto Smite)</font>")
        PrintToChat("<font color=""#00ff00"">F8 (Quick Cast)</font>")
        PrintToChat("<font color=""#00ff00"">F10 (Aimbot)</font>")
        PrintToChat("<font color=""#ff0000"">-------------------------------</font>")

        Dim lp As LolClasses.LolObject = getLocalPlayer()
        For i = 0 To 6
            Console.WriteLine(lp.GetSpell(i).Name & " " & lp.GetSpell(i).CastType & " " & lp.GetSpell(i).TargetType)
        Next
        'MS.memory.ExecuteAtAddress(&H320000)
    End Sub
    Public Shared Function lolStringRead(ByVal address As Integer) As String
        Dim length As Integer = MS.memory.readInt(address + &H10)
        If length > 15 Then
            Return MS.memory.readString(MS.memory.readInt(address), length)
        Else
            Return MS.memory.readString(address, length)
        End If
    End Function
    Private Sub UpdateMouse()
        Dim ss As New cMem.Memory.Vector3
        While CursorThreadActive
            If Not CursorPause Then
                ss.x = getCursor.CursorX
                ss.y = getCursor.CursorY
                ss.z = getCursor.CursorZ
                MS.memory.WriteMemory(CursorVecAddress, ss)
            End If
        End While
    End Sub
    Public Function HookSkillMouse() As Integer 'returns the address to the vector controlling the cursor while in a skill
        Dim s As New cMem.Memory.Vector3
        s.x = getCursor.CursorX
        s.y = getCursor.CursorY
        s.z = getCursor.CursorZ
        MS.memory.WriteMemory(0, s)
        Dim asm As New cMem.Assembler
        Dim vecadd As Integer = MS.memory.LastAddress
        asm.fasm.AddLine("use32")
        asm.fasm.AddLine("push edx")
        asm.fasm.AddLine("mov eax, dword [ebp+0x8]")
        asm.fasm.AddLine("mov edx, {0}", MS.memory.LastAddress)
        asm.fasm.AddLine("fld dword [edx]")
        asm.fasm.AddLine("fstp dword [ecx+0x18]")
        asm.fasm.AddLine("fld dword [edx+0x4]")
        asm.fasm.AddLine("fstp dword [ecx+0x1c]")
        asm.fasm.AddLine("fld dword [edx+0x8]")
        asm.fasm.AddLine("fstp dword [ecx+0x20]")
        asm.fasm.AddLine("pop edx")
        asm.fasm.AddLine("pop ebp")
        asm.fasm.AddLine("retn 4")
        MS.memory.WriteMemory(0, asm.fasm.Assemble())
        asm.fasm.Clear()

        asm.fasm.AddLine("use32")
        asm.fasm.AddLine("push ebp")
        asm.fasm.AddLine("mov ebp,esp")
        asm.fasm.AddLine("mov edx,{0}", MS.memory.LastAddress)
        asm.fasm.AddLine("jmp edx")
        asm.fasm.AddLine("nop")
        MS.memory.WriteMemory(lolbase + Functions.SetCastCursorLocation, asm.fasm.Assemble)

        MoveMouseThread = New Thread(AddressOf UpdateMouse)
        MoveMouseThread.IsBackground = True
        MoveMouseThread.Start()
        CursorVecAddress = vecadd
        asm = Nothing
        'PrintToChat("<font color=""#ff00ff"">Mouse is hooked for skill shots</font>")
        Return vecadd
    End Function
    Public Sub FloatingText(ByVal Message As String, ByVal type As FloatingTextTypes, Optional ByVal lobject As LolClasses.LolObject = Nothing)
        Dim asm As New cMem.Assembler
        MS.memory.WriteMemory(0, Message)
        asm.fasm.AddLine("use32")
        asm.fasm.AddLine("push 0")
        asm.fasm.AddLine("push 0")
        asm.fasm.AddLine("push {0}", MS.memory.LastAddress) 'push address containing the string to be printed
        asm.fasm.AddLine("push {0}", DirectCast(type, Integer))
        If lobject Is Nothing Then
            asm.fasm.AddLine("push {0}", getLocalPlayer.BaseAddress)
        Else
            asm.fasm.AddLine("push {0}", lobject.BaseAddress)
        End If
        asm.fasm.AddLine("mov ecx, {0}", MS.memory.readInt(lolbase + FloatingTextUnk1))
        asm.fasm.AddLine("mov eax, {0}", lolbase + Functions.FloatingText)
        asm.fasm.AddLine("call eax")
        asm.fasm.AddLine("retn")
        MS.memory.ExecuteFasm(asm, False)
        asm = Nothing
    End Sub
    Public Sub PrintToChat(ByVal Message As String, Optional ByVal type As Integer = 2)
        Dim asm As New cMem.Assembler
        Message = "<font color=""#990000"">-></font> " & Message
        MS.memory.WriteMemory(0, Message)
        asm.fasm.AddLine("use32")
        asm.fasm.AddLine("push {0}", type)
        asm.fasm.AddLine("push {0}", MS.memory.LastAddress) 'push address containing the string to be printed
        asm.fasm.AddLine("mov ecx, {0}", lolbase + ChatMsgUnk1)
        asm.fasm.AddLine("mov eax, {0}", lolbase + Functions.PrintChat)
        asm.fasm.AddLine("call eax")
        asm.fasm.AddLine("retn")

        MS.memory.ExecuteFasm(asm, False)
        asm.fasm.Clear()
        asm = Nothing
    End Sub

    Public Sub CastSpell(ByVal vec3 As Memory.Vector3, ByVal slot As Integer)
        MS.memory.WriteMemory(0, vec3)
        CastSpell(0, slot, MS.memory.LastAddress)
    End Sub
    Public Sub CastSpell(ByVal obj As LolClasses.LolObject, ByVal slot As Integer)
        CastSpell(obj.UnitID, slot, obj.LocationPtr)
    End Sub
    Public Sub CastSpell(ByVal unit As Integer, ByVal slot As Integer, ByVal location As Integer)
        Dim scast As IntPtr = lolbase + Functions.Cast
        If slot < 6 Then
            getLocalPlayer.SpellSlot = slot
        End If
        Dim asm As New cMem.Assembler
        asm.fasm.AddLine("use32")
        asm.fasm.AddLine("push 1")
        asm.fasm.AddLine("push {0}", unit)
        asm.fasm.AddLine("push {0}", location)
        asm.fasm.AddLine("push {0}", location)
        If slot > 3 Then
            asm.fasm.AddLine("mov ecx, {0}", getLocalPlayer.SummonerSCIPtr)
        Else
            asm.fasm.AddLine("mov ecx, {0}", getLocalPlayer.ChampionSCIPtr)
        End If
        asm.fasm.AddLine("mov eax, {0}", lolbase + Functions.Cast)
        asm.fasm.AddLine("call eax")
        asm.fasm.AddLine("retn")
        MS.memory.ExecuteFasm(asm, False)
        asm = Nothing
        getLocalPlayer.SpellSlot = -1
    End Sub
    Public Sub MoveTo(ByVal move_type As LolStructs.MoveType, ByVal obj_address As Integer, ByVal location As Memory.Vector3)
        Dim asm As New cMem.Assembler
        Dim vector_address As Long = 0
        If move_type = LolStructs.MoveType.Attack And obj_address = 0 Then
            PrintToChat("Invalid Target for MoveTo")
            Exit Sub
        End If
        asm.fasm.AddLine("use32")

        'argument 6
        If move_type = LolStructs.MoveType.Hold Then
            asm.fasm.AddLine("push 1")
        Else
            asm.fasm.AddLine("push {0}", lolbase + &H4EB101)
        End If

        'argument 5
        asm.fasm.AddLine("push 0")

        'argument 4
        asm.fasm.AddLine("push 0")

        'arguments 2/3
        Select Case move_type
            Case LolStructs.MoveType.Attack
                asm.fasm.AddLine("push {0}", obj_address)
                asm.fasm.AddLine("push {0}", obj_address + &H60)
            Case LolStructs.MoveType.Move
                vector_address = MS.memory.AllocMem(Marshal.SizeOf(location))
                MS.memory.WriteMemory(vector_address, location)
                asm.fasm.AddLine("push 0")
                asm.fasm.AddLine("push {0}", vector_address)
            Case LolStructs.MoveType.Hold
                asm.fasm.AddLine("push 0")
                asm.fasm.AddLine("push {0}", MS.memory.readInt(lolbase + Structs.LocalPlayer) + &H60) 'local player (position vector)
        End Select
        'argument 1
        asm.fasm.AddLine("push {0}", DirectCast(move_type, Integer))
        'move local player into ecx
        asm.fasm.AddLine("mov ecx,{0}", MS.memory.readInt(lolbase + Structs.LocalPlayer)) 'local player
        'move function to call into ebx
        asm.fasm.AddLine("mov eax,{0}", lolbase + Functions.MoveTo)
        'call function
        asm.fasm.AddLine("call eax")
        'return
        asm.fasm.AddLine("retn")
        MS.memory.ExecuteFasm(asm, False)
        asm.fasm.Clear()
        If vector_address <> 0 Then
            MS.memory.VirtualFreeEx(vector_address, Marshal.SizeOf(location), &H40000)
        End If
        asm = Nothing
    End Sub
    Public Function getNops(ByVal count As Integer) As Byte()
        Dim b(count - 1) As Byte
        For i = 0 To b.Count - 1
            b(i) = &H90
        Next
        Return b
    End Function

    Public Shared Function getCamera() As LolStructs.Camera
        Dim local_camera As LolStructs.Camera = New LolStructs.Camera
        byteArraytoStruct(local_camera, getHudMgr.Camera)
        Return local_camera
    End Function
    Public Shared Function getCursor() As LolStructs.CursorMoveTo
        Dim local_cursor As LolStructs.CursorMoveTo = New LolStructs.CursorMoveTo
        byteArraytoStruct(local_cursor, getHudMgr.Cursor)
        Return local_cursor
    End Function
    Public Shared Function getClock() As LolClasses.LolClock
        Dim local_clock As New LolClasses.LolClock(MS.memory.readInt(lolbase + Structs.GameClock))
        Return local_clock
    End Function
    Public Shared Function getHudMgr() As LolStructs.HudManager
        Dim local_hud As LolStructs.HudManager
        byteArraytoStruct(local_hud, MS.memory.readInt(lolbase + Structs.HudManager))
        Return local_hud
    End Function
    Public Shared Function getLocalPlayer() As LolClasses.LolObject
        Dim local_player As LolClasses.LolObject = New LolClasses.LolObject(MS.memory.readInt(lolbase + Structs.LocalPlayer))
        Return local_player
    End Function
    Public Function GetEnemyByUnit(ByVal id As Integer) As LolClasses.LolObject
        Dim lobj As LolClasses.LolObject

        Dim objMgrBase As Integer = MS.memory.readInt(lolbase + Structs.ObjManager)
        Dim objLast As Long = MS.memory.readInt(lolbase + Structs.ObjManagerMax)

        Dim CurrentObj As Long = &H0
        Dim this As Integer = 0
        Dim Nearest As Single = 100000

        Dim ptr As Integer = 0
        Dim valid As Boolean = True
        While this <> MS.memory.readInt(objLast)
            this = MS.memory.readInt(objMgrBase + CurrentObj)
            lobj = New LolClasses.LolObject(this)
            If lobj.UnitID = id Then
                Return lobj
            End If
            CurrentObj += 4
        End While
        Return Nothing
    End Function
    Public Function GetEnemyByID(ByVal id As Integer) As LolClasses.LolObject
        Dim lobj As LolClasses.LolObject

        Dim objMgrBase As Integer = MS.memory.readInt(lolbase + Structs.ObjManager)
        Dim objLast As Long = MS.memory.readInt(lolbase + Structs.ObjManagerMax)

        Dim CurrentObj As Long = &H0
        Dim this As Integer = 0
        Dim Nearest As Single = 100000

        Dim ptr As Integer = 0
        Dim valid As Boolean = True
        While this <> MS.memory.readInt(objLast)
            this = MS.memory.readInt(objMgrBase + CurrentObj)
            lobj = New LolClasses.LolObject(this)
            If lobj.ID = id Then
                Return lobj
            End If
            CurrentObj += 4
        End While
        Return Nothing
    End Function
    Public Function GetNearestEnemyChampion(ByVal range As Single) As LolClasses.LolObject
        Dim lobj As LolClasses.LolObject
        Dim nObj As LolClasses.LolObject = Nothing

        Dim local_player As LolClasses.LolObject = getLocalPlayer()

        Dim objMgrBase As Integer = MS.memory.readInt(lolbase + Structs.ObjManager)
        Dim objLast As Long = MS.memory.readInt(lolbase + Structs.ObjManagerMax)

        Dim CurrentObj As Long = &H0
        Dim this As Integer = 0
        Dim Nearest As Single = 100000
        Dim sw As New Stopwatch
        Dim distance As Single = 0
        sw.Start()
        While this <> MS.memory.readInt(objLast)
            this = MS.memory.readInt(objMgrBase + CurrentObj)
            lobj = New LolClasses.LolObject(this)
            If lobj.objType = LolStructs.objectType.Champ AndAlso lobj.HealthCurrent > 0 AndAlso lobj.BaseAddress <> local_player.BaseAddress AndAlso lobj.Team <> local_player.Team AndAlso lobj.Visibility = 0 Then
                distance = GetDistance(local_player.Location, lobj.Location)
                If distance < range Then
                    If distance < Nearest Then
                        nObj = lobj
                        Nearest = distance
                    End If
                End If
            End If
            CurrentObj += 4
        End While
        sw.Stop()
        'Console.WriteLine("Object Iteration Time: " & sw.ElapsedMilliseconds)
        Return nObj
    End Function
    Public Function GetNearestEnemy(Optional ByVal champion As Boolean = False, Optional ByVal last_hit As Boolean = False, Optional ByVal max_distance As Single = 500) As LolClasses.LolObject
        Dim lobj As LolClasses.LolObject
        Dim nObj As LolClasses.LolObject = Nothing

        Dim local_player As LolClasses.LolObject = getLocalPlayer()

        Dim objMgrBase As Integer = MS.memory.readInt(lolbase + Structs.ObjManager)
        Dim objLast As Long = MS.memory.readInt(lolbase + Structs.ObjManagerMax)

        Dim CurrentObj As Long = &H0
        Dim this As Integer = 0
        Dim Nearest As Single = 100000
        Dim sw As New Stopwatch
        Dim valid As Boolean = True
        Dim distance As Single = 0
        While this <> MS.memory.readInt(objLast)
            valid = False
            this = MS.memory.readInt(objMgrBase + CurrentObj)
            lobj = New LolClasses.LolObject(this)
            distance = GetDistance(local_player.Location, lobj.Location)
            If distance < Nearest AndAlso distance < max_distance AndAlso this <> MS.memory.readInt(lolbase + Structs.LocalPlayer) AndAlso local_player.Team <> lobj.Team AndAlso lobj.Team <> 0 AndAlso lobj.HealthCurrent > 0 AndAlso Not InStr(lobj.Name.ToLower, "turret") Then
                If last_hit And champion Then
                    If lobj.HealthCurrent < (local_player.AttackDamage + local_player.BonusAttackDamage) And lobj.objType = LolStructs.objectType.Champ Then
                        valid = True
                    End If
                ElseIf last_hit And Not champion Then
                    If lobj.HealthCurrent < (local_player.AttackDamage + local_player.BonusAttackDamage) And lobj.objType <> LolStructs.objectType.Champ Then
                        valid = True
                    End If
                ElseIf champion And Not last_hit Then
                    If lobj.objType = LolStructs.objectType.Champ Then
                        valid = True
                    End If
                ElseIf Not champion And Not last_hit Then
                    valid = True
                End If

                If valid Then
                    nObj = lobj
                    Nearest = GetDistance(local_player.Location, lobj.Location)
                End If
            End If
            CurrentObj += 4
        End While
        Return nObj
    End Function
    Public Function findSpell(ByVal name As String) As Integer
        Dim local_player As LolClasses.LolObject = getLocalPlayer()
        For i = 0 To 5
            If InStr(local_player.GetSpell(i).Name.ToLower, name.ToLower) Then
                Return i
            End If
        Next
        Return -1
    End Function
    Public Sub getInvisObjects()
        Dim lobj As LolClasses.LolObject
        Dim nObj As LolClasses.LolObject = Nothing

        Dim local_player As LolClasses.LolObject = getLocalPlayer()

        Dim objMgrBase As Integer = MS.memory.readInt(lolbase + Structs.ObjManager)
        Dim objLast As Long = MS.memory.readInt(lolbase + Structs.ObjManagerMax)

        Dim CurrentObj As Long = &H0
        Dim this As Integer = 0
        Dim Nearest As Single = 100000
        While this <> MS.memory.readInt(objLast)
            lobj = New LolClasses.LolObject(this)
            this = MS.memory.readInt(objMgrBase + CurrentObj)
            If lobj.Visibility = 16 Then
                Console.WriteLine(lobj.Name & " is invis? " & Hex(lobj.BaseAddress))
            End If
            CurrentObj += 4
        End While
        ' Console.WriteLine("Object Iteration Time: " & sw.ElapsedMilliseconds)
    End Sub
    Public Function getObjectByName(ByVal name As String) As LolClasses.LolObject
        Dim lobj As LolClasses.LolObject
        Dim nObj As LolClasses.LolObject = Nothing

        Dim local_player As LolClasses.LolObject = getLocalPlayer()

        Dim objMgrBase As Integer = MS.memory.readInt(lolbase + Structs.ObjManager)
        Dim objLast As Long = MS.memory.readInt(lolbase + Structs.ObjManagerMax)

        Dim CurrentObj As Long = &H0
        Dim this As Integer = 0
        Dim Nearest As Single = 100000
        While this <> MS.memory.readInt(objLast)
            lobj = New LolClasses.LolObject(this)
            this = MS.memory.readInt(objMgrBase + CurrentObj)
            If GetDistance(local_player.Location, lobj.Location) < Nearest And InStr(lobj.Name.ToLower, name.ToLower) Then
                nObj = lobj
                Nearest = GetDistance(local_player.Location, lobj.Location)
            End If
            CurrentObj += 4
        End While
        ' Console.WriteLine("Object Iteration Time: " & sw.ElapsedMilliseconds)
        Return nObj
    End Function
    Public Function getNearestEpic(Optional ByVal range As Single = 1000) As LolClasses.LolObject
        Dim lobj As LolClasses.LolObject
        Dim nObj As LolClasses.LolObject = Nothing

        Dim local_player As LolClasses.LolObject = getLocalPlayer()

        Dim objMgrBase As Integer = MS.memory.readInt(lolbase + Structs.ObjManager)
        Dim objLast As Long = MS.memory.readInt(lolbase + Structs.ObjManagerMax)

        Dim CurrentObj As Long = &H0
        Dim this As Integer = 0
        Dim Nearest As Single = 100000
        While this <> MS.memory.readInt(objLast)
            lobj = New LolClasses.LolObject(this)
            this = MS.memory.readInt(objMgrBase + CurrentObj)
            If GetDistance(local_player.Location, lobj.Location) < Nearest And GetDistance(local_player.Location, lobj.Location) < range And lobj.HealthCurrent > 0 And lobj.objType = LolStructs.objectType.Minion And lobj.unk1 = 15 And lobj.CampID <> 0 Then
                nObj = lobj
                Nearest = GetDistance(local_player.Location, lobj.Location)
            End If
            CurrentObj += 4
        End While
        ' Console.WriteLine("Object Iteration Time: " & sw.ElapsedMilliseconds)
        Return nObj
    End Function
    Public Shared Function GetDistance(ByVal obj1 As Memory.Vector3, ByVal obj2 As Memory.Vector3) As Single
        Dim result As Single = 0
        Dim i1 As Single = (obj1.x - obj2.x)
        Dim i2 As Single = (obj1.y - obj2.y)
        Dim i3 As Single = (obj1.z - obj2.z)
        Dim UnderRadical As Double = (i1 * i1) + (i2 * i2) + (i3 * i3)
        result = Math.Round(Math.Sqrt(UnderRadical), 2)
        Return result
    End Function

    Public Shared Sub byteArraytoStruct(ByRef obj As Object, ByVal address As Long)
        Try
            Dim Current_Object_Byte_Array() As Byte = MS.memory.readByteArray(address, Marshal.SizeOf(obj))
            Dim ptr As IntPtr = Marshal.AllocHGlobal(Marshal.SizeOf(obj))
            Marshal.Copy(Current_Object_Byte_Array, 0, ptr, Marshal.SizeOf(obj))

            obj = Marshal.PtrToStructure(ptr, obj.GetType)
            Marshal.FreeHGlobal(ptr)
        Catch ex As Exception
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.Message)
        End Try
    End Sub
    Public Shared Function getFieldOffset(ByVal obj As Object, ByVal field As String) As Integer
        If obj.GetType.GetField(field) IsNot Nothing Then
            Dim f As FieldInfo = obj.GetType.GetField(field)
            For Each att As CustomAttributeData In f.GetCustomAttributesData
                If InStr(att.ToString, "FieldOffset") Then
                    Dim offset As Integer = 0
                    Integer.TryParse(att.ToString.Split("(")(2).Split(")")(1), offset)
                    Return offset
                End If
            Next
        End If
        Return 0
    End Function
End Class
