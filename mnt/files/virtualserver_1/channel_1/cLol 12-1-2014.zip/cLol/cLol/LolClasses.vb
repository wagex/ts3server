﻿Public Class LolClasses
    Public Class LolClock
        Private objStruct As New LolStructs.GameClock
        Public BaseAddress As Integer
        Sub New(ByVal address As Integer)
            LolHelpers.byteArraytoStruct(objStruct, address)
            BaseAddress = address
        End Sub
        Public ReadOnly Property Time As Single
            Get
                Return objStruct.Time
            End Get
        End Property
    End Class
    Public Class LolSpell
        Private Spell As New LolStructs.Spell
        Private SpellInfo As New LolStructs.SpellInformation
        Private lobj As New LolStructs.lolObject
        Public BaseAddress As Integer
        Public SpellInfoBase As Integer
        Public ObjectBase As Integer
        Sub New(ByVal ObjBase As Integer, ByVal slot As Integer)
            ObjectBase = ObjBase
            If slot > 3 Then
                BaseAddress = MS.memory.readInt(ObjBase + (LolHelpers.getFieldOffset(New LolStructs.lolObject, "Summoner_SCI") + &H4F4 + (slot * 4)))
            Else
                BaseAddress = MS.memory.readInt(ObjBase + (LolHelpers.getFieldOffset(New LolStructs.lolObject, "Champion_SCI") + &H4F4 + (slot * 4)))
            End If

            LolHelpers.byteArraytoStruct(Spell, BaseAddress)
            SpellInfoBase = Spell.SpellInformation
            LolHelpers.byteArraytoStruct(SpellInfo, Spell.SpellInformation)
        End Sub


        Public ReadOnly Property TrueDamage As Single
            Get
                Return MS.memory.readFloat(BaseAddress + LolHelpers.getFieldOffset(Spell, "TrueDamage"))
            End Get
        End Property
        Public ReadOnly Property Level As Integer
            Get
                Return Spell.Level
            End Get
        End Property
        Public ReadOnly Property Name As String
            Get
                Return LolHelpers.lolStringRead(SpellInfoBase + LolHelpers.getFieldOffset(SpellInfo, "Name"))
            End Get
        End Property
        Public ReadOnly Property NameLength As Integer
            Get
                Return MS.memory.readInt(SpellInfoBase + LolHelpers.getFieldOffset(SpellInfo, "NameLength"))
            End Get
        End Property
        Public ReadOnly Property CoolDownTimeLeft As Single
            Get
                Dim rval As Single = CastedTimeStamp - LolHelpers.getClock.Time
                If rval > 0 Then
                    Return rval
                Else
                    Return 0
                End If
            End Get
        End Property
        Public ReadOnly Property TargetType As Integer
            Get
                Return MS.memory.readInt(SpellInfoBase + LolHelpers.getFieldOffset(SpellInfo, "TargetType"))
            End Get
        End Property
        Public ReadOnly Property CastType As Integer
            Get
                Return MS.memory.readInt(SpellInfoBase + LolHelpers.getFieldOffset(SpellInfo, "CastType"))
            End Get
        End Property
        Public ReadOnly Property Damage As Single
            Get
                Return MS.memory.readFloat(SpellInfoBase + (LolHelpers.getFieldOffset(SpellInfo, "BaseDamage") + (4 * (Level - 1))))
            End Get
        End Property
        Public ReadOnly Property CastedTimeStamp As Single
            Get
                Return MS.memory.readFloat(BaseAddress + LolHelpers.getFieldOffset(Spell, "CooldownTimeStamp"))
            End Get
        End Property
        Public ReadOnly Property Unk As Short
            Get
                Return MS.memory.readShort(SpellInfoBase + LolHelpers.getFieldOffset(SpellInfo, "Unk1"))
            End Get
        End Property

        Public Property Range As Single
            Get
                Dim rng As Single = MS.memory.readFloat(SpellInfoBase + (LolHelpers.getFieldOffset(SpellInfo, "Range") + (4 * (Level))))
                If rng = 0 Or rng > 8000 Then
                    Return MS.memory.readFloat(SpellInfoBase + (LolHelpers.getFieldOffset(SpellInfo, "RangeRadius") + (4 * (Level))))
                Else
                    Return rng
                End If
            End Get
            Set(value As Single)

                Dim rng As Single = MS.memory.readFloat(SpellInfoBase + (LolHelpers.getFieldOffset(SpellInfo, "Range") + (4 * (Level))))
                If rng = 0 Or rng > 8000 Then
                    MS.memory.WriteMemory(SpellInfoBase + (LolHelpers.getFieldOffset(SpellInfo, "RangeRadius") + (4 * (Level))), value)
                Else
                    MS.memory.WriteMemory(SpellInfoBase + (LolHelpers.getFieldOffset(SpellInfo, "Range") + (4 * (Level))), value)
                End If
            End Set
        End Property
        Public ReadOnly Property ManaCost As Single
            Get
                Return MS.memory.readFloat(SpellInfoBase + (LolHelpers.getFieldOffset(SpellInfo, "BaseMana") + (4 * (Level - 1))))
            End Get
        End Property
        Public ReadOnly Property isReady() As Boolean
            Get
                LolHelpers.byteArraytoStruct(lobj, ObjectBase)
                If Not isOnCooldown AndAlso Level > 0 AndAlso ManaCost <= lobj.Current_Mana AndAlso LolHelpers.getLocalPlayer.HealthCurrent > 0 Then
                    Return True
                Else
                    Return False
                End If
            End Get
        End Property
        Public ReadOnly Property isOnCooldown() As Boolean
            Get
                If CastedTimeStamp = 0 Then
                    Return False
                ElseIf CastedTimeStamp - LolHelpers.getClock.Time <= 0 Then
                    Return False
                Else
                    Return True
                End If
            End Get
        End Property
    End Class
    Public Class LolObject
        Private objStruct As New LolStructs.lolObject
        Public BaseAddress As Integer
        Sub New(ByVal address As Integer)
            BaseAddress = address
            LolHelpers.byteArraytoStruct(objStruct, BaseAddress)
        End Sub
        Public previous_location As New cMem.Memory.Vector3
        Public Function GetSpell(ByVal slot As Integer) As LolSpell
            Dim sp As New LolSpell(BaseAddress, slot)
            Return sp
        End Function
        Public Property SpellSlot As Integer
            Get
                Return MS.memory.readInt(BaseAddress + LolHelpers.getFieldOffset(objStruct, "Champion_Spell_Active_Slot"))
            End Get
            Set(value As Integer)
                If value = -1 Then
                    MS.memory.WriteMemory(BaseAddress + LolHelpers.getFieldOffset(objStruct, "Summoner_Spell_Active_Slot"), value)
                    MS.memory.WriteMemory(BaseAddress + LolHelpers.getFieldOffset(objStruct, "Champion_Spell_Active_Slot"), value)
                ElseIf value > 3 Then
                    MS.memory.WriteMemory(BaseAddress + LolHelpers.getFieldOffset(objStruct, "Summoner_Spell_Active_Slot"), value)
                Else
                    MS.memory.WriteMemory(BaseAddress + LolHelpers.getFieldOffset(objStruct, "Champion_Spell_Active_Slot"), value)
                End If
            End Set
        End Property
        Public ReadOnly Property Visibility As Byte
            Get
                Return MS.memory.readByte(BaseAddress + LolHelpers.getFieldOffset(objStruct, "Visibility"))
            End Get
        End Property
        Public ReadOnly Property Name As String
            Get
                Return LolHelpers.lolStringRead(BaseAddress + LolHelpers.getFieldOffset(objStruct, "Name"))
            End Get
        End Property
        Public ReadOnly Property MovementSpeed As Single
            Get
                Return MS.memory.readFloat(BaseAddress + LolHelpers.getFieldOffset(objStruct, "Movement_Speed"))
            End Get
        End Property
        Public ReadOnly Property Champion As String
            Get
                Return LolHelpers.lolStringRead(MS.memory.readInt(BaseAddress + LolHelpers.getFieldOffset(objStruct, "ChampionNamePtr")))
            End Get
        End Property
        Public ReadOnly Property objType As LolStructs.objectType
            Get
                Return objStruct.Type
            End Get
        End Property
        Public ReadOnly Property Location As cMem.Memory.Vector3
            Get
                Dim s As New cMem.Memory.Vector3
                s.x = MS.memory.readFloat(BaseAddress + LolHelpers.getFieldOffset(objStruct, "X"))
                s.y = MS.memory.readFloat(BaseAddress + LolHelpers.getFieldOffset(objStruct, "Y"))
                s.z = MS.memory.readFloat(BaseAddress + LolHelpers.getFieldOffset(objStruct, "Z"))
                Return s
            End Get
        End Property
        Public Sub SaveLocation()
            previous_location.x = Location.x
            previous_location.y = Location.y
            previous_location.z = Location.z
        End Sub
        Public ReadOnly Property unk1 As Integer
            Get
                Return MS.memory.readInt(BaseAddress + &H38)
            End Get
        End Property
        Public ReadOnly Property CampID As Integer
            Get
                Return objStruct.CampID
            End Get
        End Property
        Public ReadOnly Property Team As Integer
            Get
                Return objStruct.Team
            End Get
        End Property
        Public ReadOnly Property HealthCurrent As Single
            Get
                Return MS.memory.readFloat(BaseAddress + LolHelpers.getFieldOffset(objStruct, "Current_Health"))
            End Get
        End Property
        Public ReadOnly Property ManaCurrent As Single
            Get
                Return MS.memory.readFloat(BaseAddress + LolHelpers.getFieldOffset(objStruct, "Current_Mana"))
            End Get
        End Property
        Public ReadOnly Property HealthMax As Single
            Get
                Return MS.memory.readFloat(BaseAddress + LolHelpers.getFieldOffset(objStruct, "Max_Health"))
            End Get
        End Property
        Public ReadOnly Property ManaMax As Single
            Get
                Return MS.memory.readFloat(BaseAddress + LolHelpers.getFieldOffset(objStruct, "Max_Mana"))
            End Get
        End Property
        Public ReadOnly Property ChampionSCI As Integer
            Get
                Return objStruct.Champion_SCI
            End Get
        End Property
        Public ReadOnly Property NameLength As Integer
            Get
                Return objStruct.Name_Length
            End Get
        End Property
        Public ReadOnly Property LocationPtr As Integer
            Get
                Return BaseAddress + LolHelpers.getFieldOffset(objStruct, "X")
            End Get
        End Property
        Public ReadOnly Property ChampionSCIPtr As Integer
            Get
                Return BaseAddress + LolHelpers.getFieldOffset(objStruct, "Champion_SCI")
            End Get
        End Property
        Public ReadOnly Property SummonerSCIPtr As Integer
            Get
                Return BaseAddress + LolHelpers.getFieldOffset(objStruct, "Summoner_SCI")
            End Get
        End Property
        Public ReadOnly Property AttackDamage As Single
            Get
                Return MS.memory.readFloat(BaseAddress + LolHelpers.getFieldOffset(objStruct, "Attack_Damage"))
            End Get
        End Property
        Public ReadOnly Property BonusAttackDamage As Single
            Get
                Return MS.memory.readFloat(BaseAddress + LolHelpers.getFieldOffset(objStruct, "Bonus_Attack_Damage"))
            End Get
        End Property
        Public ReadOnly Property ID As Integer
            Get
                Return objStruct.ID
            End Get
        End Property
        Public ReadOnly Property UnitID As Integer
            Get
                Return objStruct.UnitID
            End Get
        End Property
    End Class
End Class
