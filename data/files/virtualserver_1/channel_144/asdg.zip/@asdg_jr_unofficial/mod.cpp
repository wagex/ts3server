name = "ASDG_JR Unofficial";
author = "Torndeco";
dir = "@asdg_jr_unofficial";