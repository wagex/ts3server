This is an un-official version of ASDG_JR, backported updates from CBA.
This is purely if you don't want to run CBA just for ASDG_JR support for weapon mods.

Licensed under GNU General Public License (GPLv2)

Credits:
Original Creator Robolo        https://forums.bistudio.com/topic/157965-asdg-joint-rails/
CBA Team for Updating ASDG_JR  https://github.com/CBATeam/CBA_A3/tree/master/addons/jr